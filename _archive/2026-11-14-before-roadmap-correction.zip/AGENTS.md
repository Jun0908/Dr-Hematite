# AGENTS.md — Dr. Hematite 共通文脈

## 企画の核

NASAの実際の火星データから資源を探し、化学・素材・発明ロードマップを開拓し、有限の生命維持資源と予期せぬ事故を乗り越える教育ゲーム。小学生高学年〜高校生を想定し、直感的で説明書なしでも遊べるUIを志向する。

## 読んでほしい順番

1. [README.md](README.md) と [現在地](docs/CURRENT_STATE.md)
2. [NASA_RESOURCE_MAPS.md](docs/science/NASA_RESOURCE_MAPS.md)（最重要）
3. [SCIENCE_ROADMAP.md](docs/science/SCIENCE_ROADMAP.md)（最重要）
4. [NASA_CHALLENGE_JUDGING.md](docs/submission/NASA_CHALLENGE_JUDGING.md)
5. [GAME_CONCEPT.md](docs/design/GAME_CONCEPT.md)（現行コンセプト）。比較が必要なときは [GAME_DESIGN_OPTIONS.md](docs/design/GAME_DESIGN_OPTIONS.md)
6. [決定記録](docs/DECISIONS.md) と、必要に応じて他の `docs/`・`assets/`。

## 判断の置き方

- 既に共有した企画の核と、数値・システム案などの未決定事項を区別する。
- NASA観測・観測に基づく推定・実証済み技術・モデル研究・ゲーム上の抽象化を区別する。
- 科学の面白さ、遊びの緊張感、学びやすさを並行して考える。
- ユーザーはDr.STONE的な素材・発明・文明の連鎖を明確に維持したい。現行コンセプトは、その核を保ち、発明操作・経済・地図・生存圧力・事故・目標の6つの課題に対応した設計。数値や学習効果は試作で検証する。
- 実装の分担はゲームの方向と作業量に応じて決める。4 Agentsは必要時の選択肢で、常時使用を前提としない。

## 資料の扱い方

- 現在の段階と検討の焦点は `docs/CURRENT_STATE.md`、共有済みの核と判断の履歴は `docs/DECISIONS.md` を参照する。
- アイデアや仮値は候補として記載し、決定として残すときは根拠・理由・影響する資料を添える。ユーザーの新しい指示を優先する。
- 科学の根拠は `docs/science/`、ゲーム案は `docs/design/`、提出条件は `docs/submission/` に記載する。関連する説明は複製よりリンクを使う。
- `assets/roadmaps/` は教育用コンセプト画像。工程の科学的条件は `docs/science/` の文章と出典で確認する。
- `_archive/` は整理前の保存用。通常の資料読み込みでは現行の `docs/` を使う。
- ファイルを移動したら、README・関連資料・スクリプト内の参照先も更新する。
