# Dr. Hematite

火星で有限の備蓄から出発し、**NASAの実際の観測データを手がかりに資源を探し、化学・素材の発明で基地を育て、予期せぬ危機を乗り越える**教育ゲーム。

NASA Space Apps Challenge 2026「Build a Junior Astronaut Mission Trainer」向けの企画資料。小学生高学年〜高校生を想定し、説明書なしでも遊び始められるUIを目指す。現在は企画・ゲーム性の検討段階。

現行の統合コンセプトは **[発明で、火星に自由をつくる](docs/design/GAME_CONCEPT.md)**。発明の操作、人手・材料・電力による進行、探索と危機への備えを、最初の「砂嵐を越える」ミッションへまとめている。

ゲームの流れを一枚で見る：[コンセプトイラスト](assets/concepts/dr-hematite-gameplay-concept.png)。画面構想であり、実際に動くゲームのスクリーンショットではない。

ゲームの流れを一枚で見る：[コンセプトイラスト](assets/concepts/dr-hematite-gameplay-concept.png)。画面構想であり、実際に動くゲームのスクリーンショットではない。

## 最初に読む

1. [現在地](docs/CURRENT_STATE.md) — 今どの段階で、何を考えているか。
2. [NASA資源地図](docs/science/NASA_RESOURCE_MAPS.md) — **最重要**。観測が示すものと、ゲームへの使い方。
3. [科学・発明ロードマップ](docs/science/SCIENCE_ROADMAP.md) — **最重要**。資源・化学・素材・生命維持のつながり。
4. [課題・審査・提出](docs/submission/NASA_CHALLENGE_JUDGING.md) — 作品で扱う課題と提出条件。
5. [現行のゲームコンセプト](docs/design/GAME_CONCEPT.md) — 発明・資源管理・探索・危機対応をつなぐ設計。[比較案](docs/design/GAME_DESIGN_OPTIONS.md)も参照。

エージェント向けの共通指示はルートの [AGENTS.md](AGENTS.md)。新しいチャットへ引き継ぐ依頼文は [CODEX_START_HERE.md](docs/CODEX_START_HERE.md)。

## フォルダ構成

```text
Dr_Hematite/
├─ README.md                 # 全体の入口と資料案内
├─ AGENTS.md                 # エージェント共通指示
├─ docs/
│  ├─ CURRENT_STATE.md       # 現在の段階・検討の焦点
│  ├─ DECISIONS.md           # 共有済みの核・今後の決定記録
│  ├─ PROJECT_BRIEF.md       # 企画の背景と目指すプレイヤー体験
│  ├─ CODEX_START_HERE.md    # 引き継ぎ用の依頼文
│  ├─ design/               # ゲーム性・教育UX・未解決の問い
│  ├─ science/              # NASA資源地図・科学・出典
│  └─ submission/           # 課題・審査・提出要件
├─ assets/
│  ├─ roadmaps/             # オリジナルの発明ノートのコンセプト画像
│  ├─ submission/           # ユーザー提供の東京会場スライド
│  └─ nasa_maps/            # 地図の出典台帳・画像の取得先
├─ scripts/                 # NASA画像取得などの補助スクリプト
└─ _archive/                # 整理前の資料一式（ZIP）
```

## 話題から探す

| 考えたいこと | 主な資料 |
|---|---|
| 今の段階・検討の焦点 | [CURRENT_STATE](docs/CURRENT_STATE.md) |
| 共有済みの核・合意の履歴 | [DECISIONS](docs/DECISIONS.md) |
| 世界観・対象年齢・体験の核 | [PROJECT_BRIEF](docs/PROJECT_BRIEF.md) |
| 現行コンセプト・最初のミッション・6つの課題への対応 | [GAME_CONCEPT](docs/design/GAME_CONCEPT.md) |
| ポイント経済・内政・危機・勝利条件 | [GAME_DESIGN_OPTIONS](docs/design/GAME_DESIGN_OPTIONS.md) |
| 初回操作・画面・学習の確かめ方 | [UX_EDUCATION](docs/design/UX_EDUCATION.md) |
| これまでの議論・未決定の問い | [IDEAS_AND_OPEN_QUESTIONS](docs/design/IDEAS_AND_OPEN_QUESTIONS.md) |
| 資源がどこにあり、地図から何が言えるか | [NASA_RESOURCE_MAPS](docs/science/NASA_RESOURCE_MAPS.md) |
| 素材・反応・発明の依存関係 | [SCIENCE_ROADMAP](docs/science/SCIENCE_ROADMAP.md) |
| 実証・実験・設計研究の違い | [SCIENCE_RESEARCH](docs/science/SCIENCE_RESEARCH.md) |
| 公式サイト・論文の出典 | [REFERENCES](docs/science/REFERENCES.md) |
| 課題・審査・東京会場の提出資料 | [NASA_CHALLENGE_JUDGING](docs/submission/NASA_CHALLENGE_JUDGING.md) |
| 過去の関連受賞作と企画への示唆 | [PAST_WINNERS](docs/submission/PAST_WINNERS.md) |
| 同梱画像の意味と由来 | [assets/README](assets/README.md) |

## 資料を育てるとき

- アイデアは該当する設計資料に追記する。合意した判断は理由とともに [DECISIONS](docs/DECISIONS.md) に残し、検討の焦点が変わったら [CURRENT_STATE](docs/CURRENT_STATE.md) を更新する。
- 観測・実証・設計研究と、ゲーム上の仮定を区別する。DP、採掘収量、ターン数などの例示値は未決定。
- 科学の詳細は `docs/science/`、ゲームの選択肢は `docs/design/` を主な記載場所にし、他の資料からリンクする。
- 科学と地図の外部出典、イベントの最新条件は、実際に利用する段階で確認する。外部の確認状況は各調査資料に記録する。

## NASA地図の取得

NASA地図画像の原本は未同梱。識別子・公式説明・画像URLは [NASA_RESOURCE_MAPS](docs/science/NASA_RESOURCE_MAPS.md)、取得対象は [出典台帳](assets/nasa_maps/source_manifest.json) にある。

ネット接続可能な環境で、ルートから任意で実行する：

```powershell
python scripts/fetch_nasa_maps.py
```

保存先は `assets/nasa_maps/`。画像の濃淡をそのまま採掘量とみなさない。詳しくは [取得案内](assets/nasa_maps/README.md)。

## 整理前の資料

2026-11-14に資料を用途別に再配置した。元の一式は [_archive/2026-11-14-before-reorganization.zip](_archive/2026-11-14-before-reorganization.zip) に保存している。現在の議論ではこのREADMEからたどれる資料を参照する。
