# 同梱画像の由来と位置づけ

- `roadmaps/01_water_oxygen_food.png` — このチャットで生成した**オリジナルの教育用コンセプトイラスト**。水氷→水→電気分解→酸素、水耕栽培などのロードマップ。
- `roadmaps/02_materials_3dprinting.png` — このチャットで生成した素材・ガラス・金属・3Dプリントのコンセプト図。
- `roadmaps/03_bioplastics_phb.png` — このチャットで生成したPHBなど素材研究を含むコンセプト図。
- `submission/tokyo_submission.png` — ユーザーが提供した東京会場の提出形式に関するスライド画像。
- `submission/tokyo_criteria.png` — ユーザーが提供した東京会場の5審査基準に関するスライド画像。

イラストは設計を考えるための説明図であり、各素材・反応の全工程を科学的に実証・記載したフローチャートではない。正確な条件と根拠は `SCIENCE_ROADMAP.md` と `REFERENCES.md` を参照。

参照としてユーザーが提示した既存漫画の原作画像はZIPに同梱していない。ゲームとプレゼンで使うビジュアルはオリジナルの表現とする。
